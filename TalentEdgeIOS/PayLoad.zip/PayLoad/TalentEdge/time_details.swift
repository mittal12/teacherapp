//
//  time_details.swift
//  TalentEdge
//
//  Created by Ashish Mittal  on 12/06/17.
//  Copyright © 2017 Aditya Sharma. All rights reserved.
//

import Foundation
class time_details:NSObject
{
    var in_time = NSNumber()
    var out_time = NSNumber()
}
