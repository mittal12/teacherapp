//
//  Batch.swift
//  TalentEdge
//
//  Created by Ashish Mittal  on 02/06/17.
//  Copyright © 2017 Aditya Sharma. All rights reserved.
//

import Foundation

class Batch: NSObject
{
    var id = String()
   var name = String()
    var logo = String()
    var course_id = String()
    var average_rating_in_course = String()
     var start_date =  String()
    var end_date = String()

}
