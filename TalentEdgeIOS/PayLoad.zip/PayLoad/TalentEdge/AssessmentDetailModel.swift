//
//  AssessmentDetailModel.swift
//  TalentEdge
//
//  Created by Ashish Mittal  on 12/06/17.
//  Copyright © 2017 Aditya Sharma. All rights reserved.
//

import Foundation
class AssessmentDetailModel :NSObject
{
       var student_attempt_info = NSAMutableArray().withClassName(DataUtils.convertStringForAltaObjectParser("student_attempt_info"))
}
