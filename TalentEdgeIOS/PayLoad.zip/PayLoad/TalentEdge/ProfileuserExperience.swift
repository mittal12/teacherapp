//
//  ProfileuserExperience.swift
//  TalentEdge
//
//  Created by Ashish Mittal  on 24/06/17.
//  Copyright © 2017 Aditya Sharma. All rights reserved.
//

import Foundation
class ProfileuserExperience:NSObject
{
    var designation = String()
    var company = String()
    var current = Bool()
    var start_date = String()
    var end_date = String()
}
