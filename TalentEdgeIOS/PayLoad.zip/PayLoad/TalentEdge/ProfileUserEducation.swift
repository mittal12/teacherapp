//
//  ProfileUserEducation.swift
//  TalentEdge
//
//  Created by Ashish Mittal  on 24/06/17.
//  Copyright © 2017 Aditya Sharma. All rights reserved.
//

import Foundation

class ProfileUserEducation:NSObject
{
    var university = String()
    var degree = String()
    var start_date = String()
    var end_date = String()
}
