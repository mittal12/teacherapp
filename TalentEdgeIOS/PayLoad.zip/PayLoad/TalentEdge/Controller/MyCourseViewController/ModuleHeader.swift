//
//  ModuleHeader.swift
//  TalentEdge
//
//

import UIKit

class ModuleHeader: UIView{

    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var extractButton: UIButton!

}
