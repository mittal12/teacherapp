//
//  Live_Classes.swift
//  TalentEdge
//
//  Created by Ashish Mittal  on 02/06/17.
//  Copyright © 2017 Aditya Sharma. All rights reserved.
//

import Foundation
class Live_Classes:NSObject
{
    var module_name = String()
     var title = String()
     var id = String()
    var end_date = String()
    var start_date_formated = String()
    var start_date = String()
    var content_duration = String()
    var content_duration_formated = String()
    var total_invitees_in_live_class = String()
    var total_invitees_attended_in_live_class = String()
    var total_invitees_attended_in_recorded_class = String()
    var participation_percentage_in_live_class = String()
    var participation_percentage_in_recorded_class = String()
    var attendance_in_recorded_session = Bool()
    var recorded_session_attendee_info_section = String()
    var average_percentage_in_live_class = NSNumber()
    }
