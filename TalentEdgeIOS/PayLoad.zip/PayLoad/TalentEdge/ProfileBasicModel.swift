//
//  ProfileBasicModel.swift
//  TalentEdge
//
//  Created by Ashish Mittal  on 24/06/17.
//  Copyright © 2017 Aditya Sharma. All rights reserved.
//

import Foundation
class ProfileBasicModel:NSObject
{
    var name = String()
    var address = String()
    var pincode = NSNumber()
    var gender = String()
    var dob = String()
    var email = String()
    var mobile_no = NSNumber()
    var qualification = String()
    var pic = String()
}
