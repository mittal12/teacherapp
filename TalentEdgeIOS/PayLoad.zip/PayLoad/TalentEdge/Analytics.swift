//
//  Analytics.swift
//  TalentEdge
//
//  Created by Ashish Mittal  on 02/06/17.
//  Copyright © 2017 Aditya Sharma. All rights reserved.
//



import Foundation
class Analytics:NSObject
{
    var total_live_class = String()
    var total_liveclass_minutes = String()
    var total_notes = String()
    var total_notes_pages = String()
    var total_video = String()
    var total_video_minutes = String()
    var  total_assignment = String()
    var  total_assessment = String()
    var avg_notes_comp_percent = String()
    var  avg_video_comp_percent = String()
    var avg_intvideo_comp_percent = String()
    var  avg_assignment_comp_percent = String()
    var avg_assessment_comp_percent = String()
    var  avg_mplanner_comp_percent = String()
    var avg_lc_comp_percent = String()
    var assignment_students_count = String()
    var assessment_students_count = String()
    
}
