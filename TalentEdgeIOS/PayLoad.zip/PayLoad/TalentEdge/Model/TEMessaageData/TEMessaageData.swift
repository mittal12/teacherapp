//
//  TEMessaageData.swift
//  TalentEdge
//

import UIKit

class TEMessaageData: NSObject {

    var attach = String()
    var created = String()
    var from_id = NSNumber()
    var from_name = String()
    var id = NSNumber()
    var is_read = NSNumber()
    var message = String()
    var subject = String()
    var to_id = NSNumber()
}
