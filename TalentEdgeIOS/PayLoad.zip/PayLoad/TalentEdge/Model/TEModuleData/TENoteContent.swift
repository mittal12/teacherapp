//
//  TENoteContent.swift
//  TalentEdge
//
//

import UIKit

class TENoteContent: NSObject {
    
    var id = NSNumber()
    var content_path = String()
}
