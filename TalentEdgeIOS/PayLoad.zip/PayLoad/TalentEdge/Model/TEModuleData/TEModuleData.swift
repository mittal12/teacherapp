//
//  TEModuleData.swift
//  TalentEdge
//
//

import UIKit

class TEModuleData: NSObject {

    var  name = String()
    var completion_percentage = NSNumber()
    var id = NSNumber()
    var is_batchlevel = NSNumber()
    var is_default_open = NSNumber()

}
