//
//  TEAssessmentReviewTest.swift
//  TalentEdge
//
//

import UIKit

class TEAssessmentReviewTest: NSObject {

    var id = NSNumber()
    var total_questions_label = String()
    var total_questions = NSNumber()
    var total_duration_label = String()
    var total_duration = NSNumber()
    var test_type = String()
    var attempt_after_duedate = NSNumber()
    var allowes_multiple = NSNumber()
    var duration_text = String()
    var total_durations = NSNumber()

    
}
