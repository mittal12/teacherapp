//
//  TEAssesmentTestQuestionQuestion.swift
//  TalentEdge
//
//

import UIKit

class TEAssesmentTestQuestionQuestion: NSObject {

    var statement = String()
    var marks = NSNumber()
    var question_type_id = NSNumber()
    var difficulty_level_id = NSNumber()
    var id = NSNumber()
    var selected_option_id = NSArray()
    var is_attempt = String()
    var is_student_correct = String()
    var marks_label = String()
    var marks_optain = NSNumber()
    var difficulty_level = String()
    var question_type = String()
}
