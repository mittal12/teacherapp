//
//  TSAssementQuestionOption.swift
//  TalentEdge
//
//

import UIKit

class TSAssementQuestionOption: NSObject {

    var id = NSNumber()
    var option_statement = String()
    var question_id = NSNumber()
    var explanation = String()
    var is_correct_option = NSNumber()
    
}
