//
//  TEAssessmentAttemptDetails.swift
//  TalentEdge
//
//

import UIKit

class TEAssessmentAttemptDetails: NSObject {

    var duration_label = String()
    var duration = NSNumber()
    var is_latest = NSNumber()
}
