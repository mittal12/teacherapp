//
//  TEAssessmentData.swift
//  TalentEdge
//
//

import UIKit

class TEAssessmentData: NSObject {

    var Content = TEAssessmentContent()
    var Module = TEAssessmentModule()
    var Test = TEAssessmentTest()
    var is_already_attempt = NSNumber()

}
