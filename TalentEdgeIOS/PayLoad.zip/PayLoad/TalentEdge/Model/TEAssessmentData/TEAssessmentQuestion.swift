//
//  TEAssessmentQuestion.swift
//  TalentEdge
//
//

import UIKit

class TEAssessmentQuestion: NSObject {

    var id = NSNumber()
    var test_id = NSNumber()
    var content_id = NSNumber()
    var question_type_id =  NSNumber()
    var module_id = NSNumber()
    var marks = NSNumber()
    var statement = String()
    var difficulty_level_id =  NSNumber()
    var created_by = NSNumber()
    var is_deleted = NSNumber()
    var is_practice = NSNumber()
    var created_on =  String()
    var modified_on =  String()

}
