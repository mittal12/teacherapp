//
//  TEAsssessmentTestQuestion.swift
//  TalentEdge
//
//

import UIKit

class TEAsssessmentTestQuestion: NSObject {

    var id = NSNumber()
    var test_id = NSNumber()
    var content_id = NSNumber()
    var question_id =  NSNumber()
    var Question = TEAssessmentQuestion()
    
    
    
}
