//
//  TEAssessmentTest.swift
//  TalentEdge
//
//

import UIKit

class TEAssessmentTest: NSObject {

    var id = NSNumber()
    var difficulty_level_id = NSNumber()
    var platyform_id = String()
    var total_marks_label = String()
    var total_marks = NSNumber()
    var passing_marks_label = String()
    var passing_marks = NSNumber()
    var total_questions_label = String()
    var total_questions = NSNumber()
    var total_duration_label = String()
    var total_duration = NSNumber()
    var test_type_label = String()
    var test_type = String()
    var attempt_after_duedate = NSNumber()
    var allowes_multiple = NSNumber()
    var review_after_attmept = NSNumber()
    
    var marking_label = String()
    var is_negative_marking = NSNumber()
    var negative_marking = NSNumber()
    var total_duration_formated = String()
    var instructions = String()
    var duration_text = String()
    var duedate_label = String()
}
