//
//  TEAssessmentModule.swift
//  TalentEdge
//
//

import UIKit

class TEAssessmentModule: NSObject {

    var id = NSNumber()
    var name = String()
}
