//
//  TEAssessmentCompleteData.swift
//  TalentEdge
//
//

import UIKit

class TEAssessmentCompleteData: NSObject {

    var Content = TEAssessmentContent()
    var Module = TEAssessmentModule()
    var Test = TEAssessmentTest()
    var studentResult = TEStudentResult()

}
