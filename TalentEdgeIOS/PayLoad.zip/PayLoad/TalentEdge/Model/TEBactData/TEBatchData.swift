//
//  TEBatchData.swift
//  TalentEdge
//
//

import UIKit

class TEBatchData: NSObject {

    var id = NSNumber()
    var name = String()
}
