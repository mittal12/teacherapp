//
//  TENotificationData.swift
//  TalentEdge
//
//

import UIKit

class TENotificationData: NSObject {
    
    var date_created = String()
    var is_read = NSNumber()
    var id = NSNumber()
    var web_message = String()
}
