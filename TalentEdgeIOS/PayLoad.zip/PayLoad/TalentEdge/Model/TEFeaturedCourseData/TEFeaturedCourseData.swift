//
//  TEFeaturedCourseData.swift
//  TalentEdge
//
//

import UIKit

class TEFeaturedCourseData: NSObject {

    var course_image = String()
    var course_name = String()
    var course_institute = String()
    var course_start_date = String()
    var course_start_date_fomated = String()
    var duration = String()
    var id = NSNumber()
    var key_points_0 = String()
    var key_points_1 = String()
    var post_title = String()
    var view_url = String()
}
