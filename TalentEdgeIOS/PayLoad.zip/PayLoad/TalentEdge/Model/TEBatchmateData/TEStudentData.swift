//
//  TEStudentData.swift
//  TalentEdge
//
//

import UIKit

class TEStudentData: NSObject {
    var id = NSNumber()
    var name = String()
    
    var isSelected = Bool()
}
