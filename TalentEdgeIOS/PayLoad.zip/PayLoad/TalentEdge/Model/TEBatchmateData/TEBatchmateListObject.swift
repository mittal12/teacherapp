//
//  TEBatchmateListObject.swift
//  TalentEdge
//
//

import UIKit

class TEBatchmateListObject: NSObject {

    var city = String()
    var country = String()
    var id = NSNumber()
    var image = String()
    var name = String()
    var qualification = String()
    var last_active = String()
}
