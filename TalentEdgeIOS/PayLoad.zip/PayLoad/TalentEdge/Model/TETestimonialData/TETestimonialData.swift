//
//  TETestimonialData.swift
//  TalentEdge
//
//

import UIKit

class TETestimonialData: NSObject {


    
    var allow_delete = NSNumber()
    var batch_id = NSNumber()
    var created = String()
    var created_by = String()
    var created_by_role = String()
    var desc = String()
    var id = NSNumber()
    var pic = String()
    var uploads = String()
    var user_id = NSNumber()
    var user_type = NSNumber()
}
