//
//  TEDiscussion.swift
//  TalentEdge
//
//

import UIKit

class TEDiscussion: NSObject {

    var avg_rating = String()
    var created_by = String()
    var desc = String()
    var id = NSNumber()
    var pic = String()
    var start_date = String()
    var title = String()
    var user_role = String()
}
