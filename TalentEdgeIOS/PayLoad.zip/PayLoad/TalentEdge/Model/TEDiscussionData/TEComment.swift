//
//  TEComment.swift
//  TalentEdge
//
//

import UIKit

class TEComment: NSObject {
    var comment = String()
    var created = String()
    var created_by = NSNumber()
    var created_by_name = String()
    var id = NSNumber()
    var pic = String()
    var user_role = String()
}
