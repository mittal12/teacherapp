//
//  TELoginData.swift
//  TalentEdge
//
//

import UIKit

class TELoginData: NSObject {
    
    var status = NSNumber()
    var token = String()
    var resultData = TEResultData()
    
}
