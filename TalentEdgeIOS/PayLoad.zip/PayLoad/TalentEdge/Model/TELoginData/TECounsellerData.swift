//
//  TECounsellerData.swift
//  TalentEdge
//
//

import UIKit

class TECounsellerData: NSObject {
    
    var id = NSNumber()
    var name = String()
    var dob = String()
    var email = String()
    var mobile_no = String()
    var pic = String()
    var qualification = String()
    var city_id = NSNumber()
    var last_login = String()
    var country_id = NSNumber()
    var batch_id = NSNumber()
}
