//
//  TEResultData.swift
//  TalentEdge
//
//

import UIKit

class TEResultData: NSObject {

    var user = TEUserData()
    var counsellor = TECounsellerData()

}
