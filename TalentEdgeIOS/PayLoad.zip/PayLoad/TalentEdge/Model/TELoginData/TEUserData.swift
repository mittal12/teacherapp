//
//  TEUserData.swift
//  TalentEdge
//
//

import UIKit

class TEUserData: NSObject {
    var userId = NSNumber()
    var username = String()
    var fName = String()
    var lName = String()
    var email = String()
    var avtar_url = String()
    var mobile_no = String()
    var referral_code = String()
}
