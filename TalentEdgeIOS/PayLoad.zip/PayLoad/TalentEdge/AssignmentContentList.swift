//
//  AssignmentContentList.swift
//  TalentEdge
//
//  Created by Ashish Mittal  on 12/06/17.
//  Copyright © 2017 Aditya Sharma. All rights reserved.
//

import Foundation

class student_submission_info :NSObject
{
    /*
     "user_id": "34",
     "fname": "Vishal",
     "lname": "Sharma",
     "email": "virendra.bhardwaj@talentedge.in",
     "pic": "http://localhost/LMS/files/profile/original_1374833708.jpg",
     "submission_id": "47",
     "is_received": "1",
     "upload_path": "",
     "uploaded_date": "",
     "uploaded_date_formatted": "",
     "marks_given_by_faculty": "Y",
     "assignment_marks": "91",
     "reviewed_date": "2017-04-11 12:55:11",
     "reviewed_date_formatted": "Apr 11, 2017 12:55 PM"

     
     
 */
    var user_id = String()
    var fname = String()
    var lname = String()
    var email = String()
    var pic = String()
    var submission_id = String()
    var is_received = String()
    var upload_path = String()
    var uploaded_date = String()
    var uploaded_date_formatted = String()
    var marks_given_by_faculty = String()
    var assignment_marks = String()
     var reviewed_date = String()
    var reviewed_date_formatted = String()
    
}
