//
//  Assignment+CoreDataClass.swift
//  TalentEdge
//
//

import Foundation
import CoreData


open class Assignment: NSManagedObject {

}
