//
//  Course.swift
//  TalentEdge
//
//  Created by Ashish Mittal  on 02/06/17.
//  Copyright © 2017 Aditya Sharma. All rights reserved.
//

import Foundation
class Course :NSObject
{
    
    var id = String()
    var name = String()
    var institute_id = String()
    
}
