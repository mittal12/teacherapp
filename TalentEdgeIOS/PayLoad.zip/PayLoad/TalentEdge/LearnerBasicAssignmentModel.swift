//
//  LearnerBasicAssignmentModel.swift
//  TalentEdge
//
//  Created by Ashish Mittal  on 24/06/17.
//  Copyright © 2017 Aditya Sharma. All rights reserved.
//

import Foundation
class LearnerBasicAssignmentModel:NSObject
{
    var completed = NSNumber()
    var total = NSNumber()
}
