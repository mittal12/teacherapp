//
//  TEAssignmentDetailAssignment.swift
//  TalentEdge
//
//

import UIKit

class TEAssignmentDetailAssignment: NSObject {
    var id = NSNumber()
    var duedate_label = String()
    var attempt_after_duedate = NSNumber()
    var multiple_submission_label = String()
    var allowed_multiple = NSNumber()
    var submission_label = String()
    var submission_mode = String()
    var graded_label = String()
    var is_graded = String()
    var total_marks_label = String()
    var total_marks = NSNumber()
    var passing_marks_label = String()
    var passing_marks = NSNumber()
    var instructions = String()
    
    
}
