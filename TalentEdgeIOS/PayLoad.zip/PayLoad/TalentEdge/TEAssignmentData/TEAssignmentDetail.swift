//
//  TEAssignmentDetail.swift
//  TalentEdge
//
//

import UIKit

class TEAssignmentDetail: NSObject {
    var Content = TEAssignmentDetailContent()
    var Assignment = TEAssignmentDetailAssignment()
    var Module = TEAssignmentDetailModule()
    var canAttempt = NSNumber()
    var is_already_attempt = NSNumber()
}
