//
//  TEAssignmentDetailModule.swift
//  TalentEdge
//

import UIKit

class TEAssignmentDetailModule: NSObject {
    var id = NSNumber()
    var name = String()
}
