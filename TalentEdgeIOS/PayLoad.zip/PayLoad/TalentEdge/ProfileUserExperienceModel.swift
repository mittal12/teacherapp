//
//  ProfileUserExperienceModel.swift
//  TalentEdge
//
//  Created by Ashish Mittal  on 25/06/17.
//  Copyright © 2017 Aditya Sharma. All rights reserved.
//

import Foundation
class ProfileuserExperienceModel:NSObject
{
    var designation = String()
    var company = String()
    var current = String()
    var start_date = String()
    var end_date = String()
}
