//
//  AssignmentDetailModel.swift
//  TalentEdge
//
//  Created by Ashish Mittal  on 12/06/17.
//  Copyright © 2017 Aditya Sharma. All rights reserved.
//

import Foundation

class AssignmentDetailModel:NSObject
{
    var student_submission_info = NSAMutableArray().withClassName(DataUtils.convertStringForAltaObjectParser("student_submission_info"))
}
