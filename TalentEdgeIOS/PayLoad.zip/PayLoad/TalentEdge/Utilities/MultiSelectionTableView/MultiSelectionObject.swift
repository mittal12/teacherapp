//
//  MultiSelectionObject.swift
//

import UIKit

class MultiSelectionObject: NSObject {

    var text_Description = String()
    var isSelected = Bool()
    var primaryKey = NSNumber()


}
