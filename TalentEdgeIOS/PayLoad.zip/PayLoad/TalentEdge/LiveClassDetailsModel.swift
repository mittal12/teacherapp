//
//  LiveClassDetailsModel.swift
//  TalentEdge
//
//  Created by Ashish Mittal  on 12/06/17.
//  Copyright © 2017 Aditya Sharma. All rights reserved.
//

import Foundation
class LiveClassDetailsModel:NSObject
{
    var student_session_info =  NSAMutableArray().withClassName(DataUtils.convertStringForAltaObjectParser("student_session_info"))
}
