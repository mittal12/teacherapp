//
//  Student_view_info.swift
//  TalentEdge
//
//  Created by Ashish Mittal  on 11/06/17.
//  Copyright © 2017 Aditya Sharma. All rights reserved.
//

import Foundation



class Student_view_info:NSObject
{
    /*
 
     "id": "34",
     "fname": "Vishal",
     "lname": "Sharma",
     "email": "virendra.bhardwaj@talentedge.in",
     "mobile_no": "9910279896",
     "pic": "http://localhost/LMS/files/profile/original_1374833708.jpg",
     "completion_percentage": "33.33",
     "last_visited": "Feb 13, 2017"

     */
    
    var id = String()
      var fname = String()
      var lname = String()
      var email = String()
    var mobile_no = String()
    var completion_percentage = String()
    var last_visited = String()
    var pic = String()
}
