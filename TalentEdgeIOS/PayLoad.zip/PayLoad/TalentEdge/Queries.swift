//
//  Queries.swift
//  TalentEdge
//
//  Created by Ashish Mittal  on 02/06/17.
//  Copyright © 2017 Aditya Sharma. All rights reserved.
//

import Foundation

class Queries:NSObject
{
    var num_queries = String()
    var num_students = String()
    var num_queries_answered = String()
}
