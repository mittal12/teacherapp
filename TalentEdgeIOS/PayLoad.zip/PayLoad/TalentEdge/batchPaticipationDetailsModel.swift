//
//  batchPaticipationDetailsModel.swift
//  TalentEdge
//
//  Created by Ashish Mittal  on 14/06/17.
//  Copyright © 2017 Aditya Sharma. All rights reserved.
//

import Foundation
class batchPaticipationDetailsModel:NSObject
{
    var class_participation_percentage_in_live_class = String()
    var class_participation_percentage_in_recorded_class = String()
}
